import glob
import subprocess
import re

import script_preprocess

def check_file_name(fname):
    """ Check the name of the sql file making sure it follows
    assignment specification
    Args:
        fname: str - The file name
    Returns:
        bool - True if file name is correct else false
    """
    fname_parts = fname.split("_")
    if "Assignment2" not in fname_parts[1]:
        return False
    res = re.search(r"\w{3}\d{3,4}", fname_parts[0])
    if res == None:
        return False
    
    return True

def check():
    correct = True

    # Check sql file
    sql_file = glob.glob("*Assignment2*")[0]
    if not check_file_name(sql_file):
        # File name is incorrect
        print("ERROR :: SQL file name: {} is incorrect, please check the assignment specification".format(sql_file))
        correct = False
    else:
        print("SUCCESS :: SQL file name looks correct")
    
    # Preprocess SQL 
    sql_file = script_preprocess.preprocess_file(sql_file) 

    # Run student SQL
    spret = subprocess.run(["psql", "-f", sql_file], capture_output=True)
    if spret.returncode < 0:
        stdout = spret.stdout.decode("utf-8")
        stderr = spret.stderr.decode("utf-8")
        print("ERROR :: Running SQL file {} returned an error:\nstdout:\n{}\nstderr:\n{}".format(sql_file, stdout, stderr))
        correct = False
    else:
        print("SUCCESS :: SQL file successfully run")

    # Check some table names etc
    spret = subprocess.run(["psql", "-c", "\connect smokedtrout", "-c", "\dt"], capture_output=True)
    stdout = spret.stdout.decode("utf-8")
    if spret.returncode < 0:
        stderr = spret.stderr.decode("utf-8")
        print("ERROR :: Running table check returned an error:\nstdout:\n{}\nstderr:\n{}".format(stdout, stderr))
        correct = False
    else:
        print("SUCCESS :: SQL table check for 'tradingroute' successfully run")
        # Check some table names are included
        table_name = "tradingroute"
        if table_name not in stdout:
            correct = False
            print("ERROR :: Could not find table name {} in output".format(table_name))
    
    # Check some attributes
    spret = subprocess.run(["psql", "-c", "\connect smokedtrout", "-c", "SELECT * FROM tradingroute WHERE false;"], capture_output=True)
    if spret.returncode < 0:
        stdout = spret.stdout.decode("utf-8")
        stderr = spret.stderr.decode("utf-8")
        print("ERROR :: Attempt to get 'tradingroute' attributes returned an error:\nstdout:\n{}\nstderr:\n{}".format(stdout, stderr))
        correct = False
    else:
        print("SUCCESS :: SQL attribute check for 'tradingroute' successfully run")
        # Check some table names are included
        stdout = spret.stdout.decode("utf-8")
        attributes = ["monitoringkey", "operatingcompany", "fleetsize", "lastyearrevenue", "taxes"]

        for attribute in attributes:
            if attribute not in stdout:
                correct = False
                print("ERROR :: Could not find attribute {} in output".format(attribute))
    
    # Check an element
    spret = subprocess.run(["psql", "-c", "\connect smokedtrout", "-c", "SELECT * FROM tradingroute WHERE monitoringkey = 1;"], capture_output=True)
    if spret.returncode < 0:
        stdout = spret.stdout.decode("utf-8")
        stderr = spret.stderr.decode("utf-8")
        print("ERROR :: Attempt to get 'tradingroute' element with monitoringkey = 1 returned an error:\nstdout:\n{}\nstderr:\n{}".format(stdout, stderr))
        correct = False
    else:
        print("SUCCESS :: SQL element check successfully run")
        # Check some table names are included
        stdout = spret.stdout.decode("utf-8")
        elements = ["1", "Sagan Enterprises", "4", "15624.05", "1874.886"]
        
        print("Output:\n{}\n".format(stdout))

        for elem in elements:
            if elem not in stdout:
                correct = False
                print("ERROR :: Could not find element {} in output".format(elem))
        
    spret = subprocess.run(["rm", "-f", sql_file])

    if correct:
        print("=== Submission looks good, no errors found ===")
    else:
        print("--- Errors exist, please see the above output ---")

if __name__ == "__main__":
    check()
