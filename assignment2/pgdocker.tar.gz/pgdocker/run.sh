#!/bin/bash

initdb /pgdata &&\
    pg_ctl -D /pgdata start &&\
    createdb

#psql -f Assignment2_Solution.sql
python3 /tmp/check_sub.py
