import re

def preprocess_file(fname):
    """ Preprocess the assignment file - deleting any '\cd' and adding our own
    Args:
        fname: str - The name of the file to preprocess
    Return:
        str - The new file name
    """

    with open(fname, "r") as afile:
        assignment_file = afile.readlines()

    cds = [] 
    for idx, line in enumerate(assignment_file):
        if "\cd" in line:
            cds += [idx]
    
    # Sort descending so we don't need to change indices as we delete
    cds.sort(reverse=True)
    for cd in cds:
        del(assignment_file[cd])

    assignment_file = ["\cd /tmp\n"] + assignment_file
    assignment_file = "".join(assignment_file)
    
    assignment_file = assignment_file.lower()

    new_name = fname.split(".")[0] + "-proc.sql"

    with open(new_name, "w") as nfile:
        nfile.write(assignment_file)

    return new_name
